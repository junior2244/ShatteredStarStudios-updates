if SERVER then
    include("battalion/sv_battalion_core.lua")
    AddCSLuaFile("battalion/cl_keybinds.lua")
end

if CLIENT then
    include("battalion/cl_keybinds.lua")
end
