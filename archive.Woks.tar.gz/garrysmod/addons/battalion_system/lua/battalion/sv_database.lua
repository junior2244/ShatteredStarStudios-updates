util.AddNetworkString("Battalion_InvitePlayer")
util.AddNetworkString("Battalion_PromotePlayer")
util.AddNetworkString("Battalion_KickPlayer")

-- Handle invites
net.Receive("Battalion_InvitePlayer", function(len, ply)
    local steamid = net.ReadString()
    local battalionName = net.ReadString()
    -- Add database logic here to add player
    -- Example: SQL.Query("INSERT INTO battalion_members ...")
    BattalionSystem.Battalions[battalionName].members[steamid] = "Recruit"
    BattalionSystem.SaveData()
end)

-- Handle promotions
net.Receive("Battalion_PromotePlayer", function(len, ply)
    local steamid = net.ReadString()
    local battalionName = net.ReadString()
    local newRank = net.ReadString()
    -- Add database logic here to update rank
    BattalionSystem.Battalions[battalionName].members[steamid] = newRank
    BattalionSystem.SaveData()
end)

-- Handle kicks
net.Receive("Battalion_KickPlayer", function(len, ply)
    local steamid = net.ReadString()
    local battalionName = net.ReadString()
    -- Add database logic here to remove player
    BattalionSystem.Battalions[battalionName].members[steamid] = nil
    BattalionSystem.SaveData()
end)
