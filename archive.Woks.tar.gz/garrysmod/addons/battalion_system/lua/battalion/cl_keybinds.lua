if SERVER then return end

BattalionSystem = BattalionSystem or {}
BattalionSystem.Battalions = BattalionSystem.Battalions or {}

local battalions = {
    ["Navy"] = {color = Color(41, 128, 185)},
    ["DT"] = {color = Color(46, 204, 113)},
    ["ISB"] = {color = Color(231, 76, 60)},
    ["Chimaera Legion"] = {color = Color(155, 89, 182)},
    ["StormTroopers"] = {color = Color(243, 156, 18)},
    ["Shock"] = {color = Color(52, 73, 94)}
}

local battalionInfo = {
    ["Navy"] = "The Imperial Navy maintains order through superior firepower and tactical excellence.",
    ["DT"] = "Death Troopers are the Empire's elite special forces unit.",
    ["ISB"] = "Imperial Security Bureau operates as the Empire's intelligence agency.",
    ["Chimaera Legion"] = "The Chimaera Legion serves as an elite strike force.",
    ["StormTroopers"] = "The backbone of Imperial ground forces.",
    ["Shock"] = "Shock Troopers specialize in urban combat and critical operations."
}

local battalionRanks = {
    ["Navy"] = {
        ["Grand Admiral"] = {level = 17, canPromote = true, canDemote = true, canKick = true, canBlacklist = true},
        ["Fleet Admiral"] = {level = 16, canPromote = true, canDemote = true, canKick = true, canBlacklist = true},
        ["Admiral"] = {level = 15, canPromote = true, canDemote = true, canKick = true},
        ["Vice Admiral"] = {level = 14, canPromote = true, canDemote = true, canKick = true},
        ["Rear Admiral"] = {level = 13, canPromote = true, canDemote = true, canKick = true},
        ["Commodore"] = {level = 12, canPromote = true, canDemote = true},
        ["Captain"] = {level = 11, canPromote = true, canDemote = true},
        ["Commander"] = {level = 10, canPromote = true, canDemote = true},
        ["Lieutenant Commander"] = {level = 9, canPromote = true, canDemote = true},
        ["Senior Lieutenant"] = {level = 8, canPromote = true, canDemote = true},
        ["Lieutenant"] = {level = 7, canPromote = true, canDemote = true},
        ["Sub-Lieutenant"] = {level = 6, canPromote = true, canDemote = true},
        ["Warrant Officer"] = {level = 5},
        ["Chief Petty Officer"] = {level = 4},
        ["Petty Officer"] = {level = 3},
        ["Leading Crewman"] = {level = 2},
        ["Crewman"] = {level = 1},
        ["Recruit"] = {level = 0}
    },
    ["DT"] = {
        ["Supreme Death Trooper"] = {level = 10, canPromote = true, canDemote = true, canKick = true, canBlacklist = true},
        ["Death Trooper Commander"] = {level = 9, canPromote = true, canDemote = true, canKick = true},
        ["Elite Death Trooper"] = {level = 8, canPromote = true, canDemote = true},
        ["Veteran Death Trooper"] = {level = 7},
        ["Advanced Death Trooper"] = {level = 6},
        ["Death Trooper"] = {level = 5},
        ["Death Scout"] = {level = 4},
        ["Death Specialist"] = {level = 3},
        ["Death Cadet"] = {level = 2},
        ["Recruit"] = {level = 1}
    },

    ["ISB"] = {
        ["Chairman"] = {level = 16, canPromote = true, canDemote = true, canKick = true, canBlacklist = true},
        ["Director"] = {level = 15, canPromote = true, canDemote = true, canKick = true, canBlacklist = true},
        ["Deputy Director"] = {level = 14, canPromote = true, canDemote = true, canKick = true, canBlacklist = true},
        ["Sector Director"] = {level = 12, canPromote = true, canDemote = true, canKick = true},
        ["Regional Director"] = {level = 11, canPromote = true, canDemote = true, canKick = true},
        ["Colonel"] = {level = 10, canPromote = true, canDemote = true},
        ["Lieutenant Colonel"] = {level = 9, canPromote = true, canDemote = true},
        ["Major"] = {level = 8, canPromote = true, canDemote = true},
        ["Captain"] = {level = 7, canPromote = true, canDemote = true},
        ["Senior Lieutenant"] = {level = 6, canPromote = true, canDemote = true},
        ["Lieutenant"] = {level = 5, canPromote = true, canDemote = true},
        ["Second Lieutenant"] = {level = 4},
        ["Senior Agent"] = {level = 3},
        ["Agent"] = {level = 2},
        ["Junior Agent"] = {level = 1},
        ["Recruit"] = {level = 0}
    },

    ["StormTroopers"] = {
        ["Marshal Commander"] = {level = 13, canPromote = true, canDemote = true, canKick = true, canBlacklist = true},
        ["Senior Commander"] = {level = 12, canPromote = true, canDemote = true, canKick = true},
        ["Regimental Commander"] = {level = 11, canPromote = true, canDemote = true, canKick = true},
        ["Commander"] = {level = 10, canPromote = true, canDemote = true},
        ["Major"] = {level = 9, canPromote = true, canDemote = true},
        ["Captain"] = {level = 8, canPromote = true, canDemote = true},
        ["Lieutenant"] = {level = 7, canPromote = true, canDemote = true},
        ["Second Lieutenant"] = {level = 6, canPromote = true, canDemote = true},
        ["Sergeant Major"] = {level = 5},
        ["Sergeant"] = {level = 4},
        ["Corporal"] = {level = 3},
        ["Trooper"] = {level = 2},
        ["Recruit"] = {level = 1}
    },
    ["Shock"] = {
        ["Marshal Commander"] = {level = 12, canPromote = true, canDemote = true, canKick = true, canBlacklist = true},
        ["Senior Commander"] = {level = 11, canPromote = true, canDemote = true, canKick = true},
        ["Regimental Commander"] = {level = 10, canPromote = true, canDemote = true, canKick = true},
        ["Commander"] = {level = 9, canPromote = true, canDemote = true},
        ["Major"] = {level = 8, canPromote = true, canDemote = true},
        ["Captain"] = {level = 7, canPromote = true, canDemote = true},
        ["Lieutenant"] = {level = 6, canPromote = true, canDemote = true},
        ["Second Lieutenant"] = {level = 5}, 
        ["Sergeant Major"] = {level = 4},
        ["Sergeant"] = {level = 3},
        ["Corporal"] = {level = 2},
        ["Trooper"] = {level = 1},
        ["Recruit"] = {level = 0}
    },
    
    ["501st"] = {
        ["Marshal Commander"] = {level = 12, canPromote = true, canDemote = true, canKick = true, canBlacklist = true},
        ["Senior Commander"] = {level = 11, canPromote = true, canDemote = true, canKick = true},
        ["Regimental Commander"] = {level = 10, canPromote = true, canDemote = true, canKick = true},
        ["Commander"] = {level = 9, canPromote = true, canDemote = true},
        ["Major"] = {level = 8, canPromote = true, canDemote = true},
        ["Captain"] = {level = 7, canPromote = true, canDemote = true},
        ["Lieutenant"] = {level = 6, canPromote = true, canDemote = true},
        ["2nd Lieutenant"] = {level = 5, canPromote = true, canDemote = true},
        ["Sergeant Major"] = {level = 4},
        ["Sergeant"] = {level = 3},
        ["Corporal"] = {level = 2},
        ["Trooper"] = {level = 1},
        ["Recruit"] = {level = 0}
    },
    
    
    ["Medical"] = {
        ["Imperial Medical Director"] = {level = 10, canPromote = true, canDemote = true, canKick = true, canBlacklist = true},
        ["Chief Medical Officer"] = {level = 9, canPromote = true, canDemote = true, canKick = true},
        ["Senior Medical Officer"] = {level = 8, canPromote = true, canDemote = true},
        ["Medical Officer"] = {level = 7},
        ["Combat Medic"] = {level = 6},
        ["Field Medic"] = {level = 5},
        ["Medical Specialist"] = {level = 4},
        ["Medical Trooper"] = {level = 3},
        ["Medical Cadet"] = {level = 2},
        ["Recruit"] = {level = 1}
    },
    
    ["Imperial Commandos"] = {
        ["Imperial Commando Commander"] = {level = 10, canPromote = true, canDemote = true, canKick = true, canBlacklist = true},
        ["Elite Commando Commander"] = {level = 9, canPromote = true, canDemote = true, canKick = true},
        ["Commando Commander"] = {level = 8, canPromote = true, canDemote = true},
        ["Commando Captain"] = {level = 7},
        ["Commando Lieutenant"] = {level = 6},
        ["Commando Sergeant"] = {level = 5},
        ["Imperial Commando"] = {level = 4},
        ["Commando Scout"] = {level = 3},
        ["Commando Cadet"] = {level = 2},
        ["Recruit"] = {level = 1}
    },
}



local function RefreshRoster(listview, battalionName)
    listview:Clear()
    
    if BattalionSystem.Battalions[battalionName] then
        for steamid, rank in pairs(BattalionSystem.Battalions[battalionName].members) do
            local ply = player.GetBySteamID(steamid)
            local name = IsValid(ply) and ply:Nick() or steamid
            local status = IsValid(ply) and "Online" or "Offline"
            listview:AddLine(name, rank, status, steamid)
        end
    end
end

local function IsInBattalion(battalionName)
    local ply = LocalPlayer()
    return BattalionSystem.Battalions[battalionName] and 
           BattalionSystem.Battalions[battalionName].members and 
           BattalionSystem.Battalions[battalionName].members[ply:SteamID()]
end

local function GetPlayerRankInfo(ply, battalionName)
    if not IsValid(ply) or not battalionName then return nil end
    
    local steamID = ply:SteamID()
    local battalion = BattalionSystem.Battalions[battalionName]
    
    if not battalion or not battalion.members or not battalion.members[steamID] then return nil end
    
    local rankName = battalion.members[steamID]
    return battalionRanks[battalionName][rankName]
end

local function CanManageMember(ply, targetSteamID, battalionName, action)
    local rankInfo = GetPlayerRankInfo(ply, battalionName)
    if not rankInfo then return false end
    
    local targetRankInfo = battalionRanks[battalionName][BattalionSystem.Battalions[battalionName].members[targetSteamID]]
    if not targetRankInfo then return false end
    
    if rankInfo.level <= targetRankInfo.level then return false end
    
    if action == "promote" then return rankInfo.canPromote end
    if action == "demote" then return rankInfo.canDemote end
    if action == "kick" then return rankInfo.canKick end
    if action == "blacklist" then return rankInfo.canBlacklist end
    
    return false
end

local function RefreshRoster(listview, battalionName)
    if not IsValid(listview) then
        -- If listview is invalid, return early and avoid the error
        return
    end
    
    listview:Clear()
    
    if BattalionSystem.Battalions[battalionName] then
        for steamid, rank in pairs(BattalionSystem.Battalions[battalionName].members) do
            local ply = player.GetBySteamID(steamid)
            local name = IsValid(ply) and ply:Nick() or steamid
            local status = IsValid(ply) and "Online" or "Offline"
            listview:AddLine(name, rank, status, steamid)
        end
    end
end

local function CreateMemberContextMenu(steamid, battalionName, rank, listview)
    local menu = DermaMenu()
    local ply = LocalPlayer()
    
  if CanManageMember(ply, steamid, battalionName, "promote") then
    local promoteMenu, _ = menu:AddSubMenu("Promote")
    for rankName, rankData in SortedPairsByMemberValue(battalionRanks[battalionName], "level", true) do
        local currentRankInfo = battalionRanks[battalionName][rank]
        if rankData.level > currentRankInfo.level and rankData.level < GetPlayerRankInfo(ply, battalionName).level then
            promoteMenu:AddOption(rankName, function()
                net.Start("Battalion_PromotePlayer")
                net.WriteString(steamid)
                net.WriteString(battalionName)
                net.WriteString(rankName)
                net.SendToServer()

                    local targetPly = player.GetBySteamID(steamid)
                    if IsValid(targetPly) then
                        local baseName = string.match(targetPly:Nick(), "[^%s]+$")
                        RunConsoleCommand("sam", "forcename", targetPly:Nick(), battalionName .. " " .. rankName .. " " .. baseName)
                    end

                    -- Ensure the listview is valid before refreshing
                    if IsValid(listview) then
                        timer.Simple(0.1, function()
                            RefreshRoster(listview, battalionName)
                        end)
                    end
                end)
            end
        end
    end

    if CanManageMember(ply, steamid, battalionName, "demote") then
        local demoteMenu, _ = menu:AddSubMenu("Demote")
        for rankName, rankData in SortedPairsByMemberValue(battalionRanks[battalionName], "level", false) do
            local currentRankInfo = battalionRanks[battalionName][rank]
            if rankData.level < currentRankInfo.level then
                demoteMenu:AddOption(rankName, function()
                    net.Start("Battalion_DemotePlayer")
                    net.WriteString(steamid)
                    net.WriteString(battalionName)
                    net.WriteString(rankName)
                    net.SendToServer()

                    local targetPly = player.GetBySteamID(steamid)
                    if IsValid(targetPly) then
                        local baseName = string.match(targetPly:Nick(), "[^%s]+$")
                        RunConsoleCommand("sam", "forcename", targetPly:Nick(), battalionName .. " " .. rankName .. " " .. baseName)
                    end

                    -- Ensure the listview is valid before refreshing
                    if IsValid(listview) then
                        timer.Simple(0.1, function()
                            RefreshRoster(listview, battalionName)
                        end)
                    end
                end)
            end
        end
    end



if CanManageMember(ply, steamid, battalionName, "kick") then
    menu:AddOption("Kick", function()
        net.Start("Battalion_KickPlayer")
        net.WriteString(steamid)
        net.WriteString(battalionName)
        net.SendToServer()

local targetPly = player.GetBySteamID(steamid)
if IsValid(targetPly) then
    local baseName = string.match(targetPly:Nick(), "[^%s]+$")
    RunConsoleCommand("sam", "forcename", targetPly:Nick(), baseName)
end

        timer.Simple(0.1, function()
            RefreshRoster(listview, battalionName)
        end)
    end)
end


    
    if CanManageMember(ply, steamid, battalionName, "blacklist") then
        menu:AddOption("Blacklist", function()
            net.Start("Battalion_Blacklist")
            net.WriteString(steamid)
            net.WriteString(battalionName)
            net.SendToServer()
            timer.Simple(0.1, function()
                RefreshRoster(listview, battalionName)
            end)
        end)
    end
    
    menu:Open()
end

function CreateBattalionMenu()
    local frame = vgui.Create("DFrame")
    frame:SetSize(ScrW(), ScrH())
    frame:Center()
    frame:SetTitle("")
    frame:MakePopup()
    frame:ShowCloseButton(false)
    frame:SetDraggable(false)

    local html = vgui.Create("DHTML", frame)
    html:Dock(FILL)

    local htmlContent = [[
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body {
                    margin: 0;
                    padding: 20px;
                    background-color: rgb(30, 30, 30);
                    color: white;
                    font-family: Arial, sans-serif;
                }
                .grid {
                    display: grid;
                    grid-template-columns: repeat(3, 1fr);
                    gap: 20px;
                    max-width: 1200px;
                    margin: 0 auto;
                }
                .battalion-card {
                    background-color: rgb(40, 40, 40);
                    border-radius: 8px;
                    padding: 20px;
                    text-align: center;
                    transition: transform 0.2s;
                }
                .battalion-card:hover {
                    transform: scale(1.02);
                }
                .battalion-logo {
                    width: 80px;
                    height: 80px;
                    border-radius: 50%;
                    margin: 0 auto 15px;
                }
                .view-btn {
                    background-color: transparent;
                    border: 2px solid;
                    border-radius: 4px;
                    color: white;
                    padding: 10px 20px;
                    cursor: pointer;
                    margin-top: 15px;
                    font-size: 14px;
                    transition: all 0.2s;
                }
                .view-btn:hover {
                    background-color: rgba(255, 255, 255, 0.1);
                }
                .close-btn {
                    position: fixed;
                    top: 20px;
                    right: 20px;
                    width: 40px;
                    height: 40px;
                    border-radius: 50%;
                    background-color: rgba(255, 0, 0, 0.8);
                    color: white;
                    border: none;
                    cursor: pointer;
                    font-size: 20px;
                }
            </style>
        </head>
        <body>
            <button class="close-btn" onclick="closeMenu()">×</button>
            <div class="grid" id="battalionGrid"></div>
            <script>
                var battalions = [
                    {name: "Navy", color: "#2980b9"},
                    {name: "DT", color: "#27ae60"},
                    {name: "ISB", color: "#c0392b"},
                    {name: "501st", color: "#8e44ad"},
                    {name: "StormTroopers", color: "#d35400"},
                    {name: "Shock", color: "#2c3e50"},
                    {name: "Medical", color: "#2c3e50"},
                    {name: "Imperial Commandos", color: "#2c3e50"}
                ];

                function createBattalionCards() {
                    var grid = document.getElementById('battalionGrid');
                    battalions.forEach(function(battalion) {
                        var card = document.createElement('div');
                        card.className = 'battalion-card';
                        card.style.border = '2px solid ' + battalion.color;
                        
                        card.innerHTML = 
                            '<div class="battalion-logo" style="background-color: ' + battalion.color + '"></div>' +
                            '<h2 style="color: ' + battalion.color + '">' + battalion.name + '</h2>' +
                            '<button class="view-btn" style="border-color: ' + battalion.color + '; color: ' + battalion.color + '"' +
                            'onclick="viewBattalion(\'' + battalion.name + '\')">' +
                            'View Battalion' +
                            '</button>';
                        
                        grid.appendChild(card);
                    });
                }

                function viewBattalion(name) {
                    window.gmod.viewBattalion(name);
                }

                function closeMenu() {
                    window.gmod.closeMenu();
                }

                createBattalionCards();
            </script>
        </body>
        </html>
    ]]

    html:SetHTML(htmlContent)

    html:AddFunction("gmod", "viewBattalion", function(battalionName)
        local battalion = battalions[battalionName]
        local listview
        
        if not IsInBattalion(battalionName) then
            notification.AddLegacy("You must be a member of this battalion", NOTIFY_ERROR, 3)
            surface.PlaySound("buttons/button10.wav")
            return
        end
        
        local rosterFrame = vgui.Create("DFrame", frame)
        rosterFrame:SetSize(ScrW() * 0.8, ScrH() * 0.8)
        rosterFrame:Center()
        rosterFrame:SetTitle(battalionName .. " Roster")
        rosterFrame:MakePopup()

        local controlPanel = vgui.Create("DPanel", rosterFrame)
        controlPanel:Dock(TOP)
        controlPanel:SetHeight(50)

        local controlPanel = vgui.Create("DPanel", rosterFrame)
        controlPanel:Dock(TOP)
        controlPanel:SetHeight(50)
    
        local refreshBtn = vgui.Create("DButton", controlPanel)
        refreshBtn:SetText("Refresh Roster")
        refreshBtn:Dock(LEFT)
        refreshBtn:SetWidth(100)
        refreshBtn.DoClick = function()
            RefreshRoster(listview, battalionName)
        end

        local requiredRankLevel = 5 -- Set the required rank level for using the invite button

-- Get the current player's rank level
local function GetPlayerRankLevel(ply, battalionName)
    if BattalionSystem.Battalions[battalionName] and BattalionSystem.Battalions[battalionName].members[ply:SteamID()] then
        local rank = BattalionSystem.Battalions[battalionName].members[ply:SteamID()]
        return battalionRanks[battalionName][rank].level
    end
    return 0 -- Return 0 if the player is not in the battalion or rank not found
end

-- Create the Invite Player button
local inviteBtn = vgui.Create("DButton", controlPanel)
inviteBtn:SetText("Invite Player")
inviteBtn:Dock(LEFT)
inviteBtn:SetWidth(100)

-- Check if the player has the required rank to use this button
local ply = LocalPlayer()
local playerRankLevel = GetPlayerRankLevel(ply, battalionName)

if playerRankLevel >= requiredRankLevel then
    -- Enable the button if the player has the required rank level
    inviteBtn.DoClick = function()
        local menu = DermaMenu()
        for _, ply in pairs(player.GetAll()) do
            if not BattalionSystem.Battalions[battalionName].members[ply:SteamID()] then
                menu:AddOption(ply:Nick(), function()
                    net.Start("Battalion_InvitePlayer")
                    net.WriteString(ply:SteamID())
                    net.WriteString(battalionName)
                    net.SendToServer()
                end)
            end
        end
        menu:Open()
    end
else
    -- If the player does not have the required rank, show a tooltip explaining the rank requirement
    inviteBtn:SetTooltip("You need rank level " .. requiredRankLevel .. " or higher to use this.")
end


        listview = vgui.Create("DListView", rosterFrame)
        listview:Dock(FILL)
        listview:AddColumn("Name")
        listview:AddColumn("Rank")
        listview:AddColumn("Status")
        listview:AddColumn("SteamID"):SetVisible(false)

        RefreshRoster(listview, battalionName)

        listview.OnRowRightClick = function(_, _, line)
            local steamid = line:GetColumnText(4)
            local rank = line:GetColumnText(2)
            CreateMemberContextMenu(steamid, battalionName, rank)
        end
    end)

    html:AddFunction("gmod", "closeMenu", function()
        frame:Remove()
    end)
end

concommand.Add("battalion_menu", CreateBattalionMenu)

hook.Add("PlayerButtonDown", "BattalionSystem_OpenMenu", function(ply, button)
    if button == KEY_F6 then
        CreateBattalionMenu()
    end
end)


-- Command: !setrank <rank_name> <level>
-- Command: !setrank <battalion_name> <rank_name> <level>
concommand.Add("setrank", function(ply, cmd, args)
    -- Check if the player is valid
    if not IsValid(ply) then return end

    -- Ensure the correct number of arguments are provided
    if #args < 3 then
        ply:PrintMessage(HUD_PRINTTALK, "Usage: !setrank <battalion_name> <rank_name> <level>")
        return
    end

    local battalionName = args[1]  -- The battalion name provided by the player
    local rankName = args[2]  -- The rank name provided by the player
    local level = tonumber(args[3])  -- The level provided by the player

    if not level then
        ply:PrintMessage(HUD_PRINTTALK, "Invalid level. Please enter a number for the level.")
        return
    end

    -- Ensure the battalion exists
    if not BattalionSystem.Battalions[battalionName] then
        ply:PrintMessage(HUD_PRINTTALK, "Invalid battalion name.")
        return
    end

    -- Ensure the rank exists in the specified battalion
    if not battalionRanks[battalionName] or not battalionRanks[battalionName][rankName] then
        ply:PrintMessage(HUD_PRINTTALK, "Invalid rank name in this battalion.")
        return
    end

    local rankData = battalionRanks[battalionName][rankName]

    -- Check if the level is within the acceptable range for that rank
    if level < rankData.level then
        ply:PrintMessage(HUD_PRINTTALK, "Level cannot be lower than the minimum level for this rank.")
        return
    end

    -- Update the player's rank and level in the battalion
    local steamID = ply:SteamID()
    if BattalionSystem.Battalions[battalionName] then
        BattalionSystem.Battalions[battalionName].members[steamID] = rankName
    else
        ply:PrintMessage(HUD_PRINTTALK, "Battalion not found.")
        return
    end

    -- Update the rank and level in the battalion ranks system
    ply:SetNWString("battalion_rank", rankName)
    ply:SetNWInt("battalion_level", level)

    ply:PrintMessage(HUD_PRINTTALK, "Your rank has been set to " .. rankName .. " with level " .. level .. " in the " .. battalionName .. " battalion.")
end)


concommand.Add("battalion_kick", function(ply, cmd, args)
    local targetSteamID = args[1]
    local battalionName = args[2]
    
    if not targetSteamID or not battalionName then
        print("Usage: battalion_kick <steamid> <battalion name>")
        return
    end
    
    net.Start("Battalion_KickPlayer")
    net.WriteString(targetSteamID)
    net.WriteString(battalionName)
    net.SendToServer()
    
    print("[Battalion] Player " .. targetSteamID .. " has been removed from " .. battalionName)
end)

net.Receive("BattalionSystem_Update", function()
    BattalionSystem.Battalions = net.ReadTable()
    if IsValid(listview) then
        RefreshRoster(listview, battalionName)
    end
end)