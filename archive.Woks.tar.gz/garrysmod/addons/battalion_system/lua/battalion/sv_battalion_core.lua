if not SERVER then return end

util.AddNetworkString("Battalion_InvitePlayer")
util.AddNetworkString("Battalion_PromotePlayer")
util.AddNetworkString("Battalion_DemotePlayer")
util.AddNetworkString("Battalion_KickPlayer")
util.AddNetworkString("BattalionSystem_Update")
util.AddNetworkString("Battalion_JoinRequest")
util.AddNetworkString("Battalion_SendDiscordWebhook")
util.AddNetworkString("Battalion_InvitePlayer")
util.AddNetworkString("Battalion_PromotePlayer") 
util.AddNetworkString("Battalion_DemotePlayer")
util.AddNetworkString("Battalion_KickPlayer")
util.AddNetworkString("Battalion_Blacklist")
util.AddNetworkString("Battalion_RemoveBlacklist")
util.AddNetworkString("BattalionSystem_Update")
util.AddNetworkString("Battalion_JoinRequest")



BattalionSystem = BattalionSystem or {}
BattalionSystem.Battalions = BattalionSystem.Battalions or {}





local battalionRanks = {
    ["Navy"] = {
        ["Grand Admiral"] = {level = 17, canPromote = true, canDemote = true, canKick = true, canBlacklist = true},
        ["Fleet Admiral"] = {level = 16, canPromote = true, canDemote = true, canKick = true, canBlacklist = true},
        ["Admiral"] = {level = 15, canPromote = true, canDemote = true, canKick = true},
        ["Vice Admiral"] = {level = 14, canPromote = true, canDemote = true, canKick = true},
        ["Rear Admiral"] = {level = 13, canPromote = true, canDemote = true, canKick = true},
        ["Commodore"] = {level = 12, canPromote = true, canDemote = true},
        ["Captain"] = {level = 11, canPromote = true, canDemote = true},
        ["Commander"] = {level = 10, canPromote = true, canDemote = true},
        ["Lieutenant Commander"] = {level = 9, canPromote = true, canDemote = true},
        ["Senior Lieutenant"] = {level = 8, canPromote = true, canDemote = true},
        ["Lieutenant"] = {level = 7, canPromote = true, canDemote = true},
        ["Sub-Lieutenant"] = {level = 6, canPromote = true, canDemote = true},
        ["Warrant Officer"] = {level = 5},
        ["Chief Petty Officer"] = {level = 4},
        ["Petty Officer"] = {level = 3},
        ["Leading Crewman"] = {level = 2},
        ["Crewman"] = {level = 1},
        ["Recruit"] = {level = 0}
    },
    ["DT"] = {
        ["Supreme Death Trooper"] = {level = 10, canPromote = true, canDemote = true, canKick = true, canBlacklist = true},
        ["Death Trooper Commander"] = {level = 9, canPromote = true, canDemote = true, canKick = true},
        ["Elite Death Trooper"] = {level = 8, canPromote = true, canDemote = true},
        ["Veteran Death Trooper"] = {level = 7},
        ["Advanced Death Trooper"] = {level = 6},
        ["Death Trooper"] = {level = 5},
        ["Death Scout"] = {level = 4},
        ["Death Specialist"] = {level = 3},
        ["Death Cadet"] = {level = 2},
        ["Recruit"] = {level = 1}
    },

    ["ISB"] = {
        ["Chairman"] = {level = 16, canPromote = true, canDemote = true, canKick = true, canBlacklist = true},
        ["Director"] = {level = 15, canPromote = true, canDemote = true, canKick = true, canBlacklist = true},
        ["Deputy Director"] = {level = 14, canPromote = true, canDemote = true, canKick = true, canBlacklist = true},
        ["Sector Director"] = {level = 12, canPromote = true, canDemote = true, canKick = true},
        ["Regional Director"] = {level = 11, canPromote = true, canDemote = true, canKick = true},
        ["Colonel"] = {level = 10, canPromote = true, canDemote = true},
        ["Lieutenant Colonel"] = {level = 9, canPromote = true, canDemote = true},
        ["Major"] = {level = 8, canPromote = true, canDemote = true},
        ["Captain"] = {level = 7, canPromote = true, canDemote = true},
        ["Senior Lieutenant"] = {level = 6, canPromote = true, canDemote = true},
        ["Lieutenant"] = {level = 5, canPromote = true, canDemote = true},
        ["Second Lieutenant"] = {level = 4},
        ["Senior Agent"] = {level = 3},
        ["Agent"] = {level = 2},
        ["Junior Agent"] = {level = 1},
        ["ISB Operative"] = {level = 0},
        ["Recruit"] = {level = 0}
    },

    ["StormTroopers"] = {
        ["Marshal Commander"] = {level = 12, canPromote = true, canDemote = true, canKick = true, canBlacklist = true},
        ["Senior Commander"] = {level = 11, canPromote = true, canDemote = true, canKick = true},
        ["Regimental Commander"] = {level = 10, canPromote = true, canDemote = true, canKick = true},
        ["Commander"] = {level = 9, canPromote = true, canDemote = true},
        ["Major"] = {level = 8, canPromote = true, canDemote = true},
        ["Captain"] = {level = 7, canPromote = true, canDemote = true},
        ["Lieutenant"] = {level = 6, canPromote = true, canDemote = true},
        ["2nd Lieutenant"] = {level = 5}, canPromote = true, canDemote = true,
        ["Sergeant Major"] = {level = 4},
        ["Sergeant"] = {level = 3},
        ["Corporal"] = {level = 2},
        ["Trooper"] = {level = 1},
        ["Recruit"] = {level = 0}
    },

    ["Shock"] = {
        ["Marshal Commander"] = {level = 12, canPromote = true, canDemote = true, canKick = true, canBlacklist = true},
        ["Senior Commander"] = {level = 11, canPromote = true, canDemote = true, canKick = true},
        ["Regimental Commander"] = {level = 10, canPromote = true, canDemote = true, canKick = true},
        ["Commander"] = {level = 9, canPromote = true, canDemote = true},
        ["Major"] = {level = 8, canPromote = true, canDemote = true},
        ["Captain"] = {level = 7}, canPromote = true, canDemote = true,
        ["Lieutenant"] = {level = 6, canPromote = true, canDemote = true},
        ["2nd Lieutenant"] = {level = 5}, canPromote = true, canDemote = true,
        ["Sergeant Major"] = {level = 4},
        ["Sergeant"] = {level = 3},
        ["Corporal"] = {level = 2},
        ["Trooper"] = {level = 1},
        ["Recruit"] = {level = 0}
    },
    
    ["501st"] = {
        ["Marshal Commander"] = {level = 12, canPromote = true, canDemote = true, canKick = true, canBlacklist = true},
        ["Senior Commander"] = {level = 11, canPromote = true, canDemote = true, canKick = true},
        ["Regimental Commander"] = {level = 10, canPromote = true, canDemote = true, canKick = true},
        ["Commander"] = {level = 9, canPromote = true, canDemote = true},
        ["Major"] = {level = 8, canPromote = true, canDemote = true},
        ["Captain"] = {level = 7, canPromote = true, canDemote = true},
        ["Lieutenant"] = {level = 6, canPromote = true, canDemote = true},
        ["2nd Lieutenant"] = {level = 5, canPromote = true, canDemote = true},
        ["Sergeant Major"] = {level = 4},
        ["Sergeant"] = {level = 3},
        ["Corporal"] = {level = 2},
        ["Trooper"] = {level = 1},
        ["Recruit"] = {level = 0}
    },
    
    
    ["Medical"] = {
        ["Imperial Medical Director"] = {level = 10, canPromote = true, canDemote = true, canKick = true, canBlacklist = true},
        ["Chief Medical Officer"] = {level = 9, canPromote = true, canDemote = true, canKick = true},
        ["Senior Medical Officer"] = {level = 8, canPromote = true, canDemote = true},
        ["Medical Officer"] = {level = 7},
        ["Combat Medic"] = {level = 6},
        ["Field Medic"] = {level = 5},
        ["Medical Specialist"] = {level = 4},
        ["Medical Trooper"] = {level = 3},
        ["Medical Cadet"] = {level = 2},
        ["Recruit"] = {level = 1}
    },
    
    ["Imperial Commandos"] = {
        ["Imperial Commando Commander"] = {level = 10, canPromote = true, canDemote = true, canKick = true, canBlacklist = true},
        ["Elite Commando Commander"] = {level = 9, canPromote = true, canDemote = true, canKick = true},
        ["Commando Commander"] = {level = 8, canPromote = true, canDemote = true},
        ["Commando Captain"] = {level = 7},
        ["Commando Lieutenant"] = {level = 6},
        ["Commando Sergeant"] = {level = 5},
        ["Imperial Commando"] = {level = 4},
        ["Commando Scout"] = {level = 3},
        ["Commando Cadet"] = {level = 2},
        ["Recruit"] = {level = 1}
    }
}

-- Initialize database
hook.Add("Initialize", "BattalionSystem_DBInit", function()
    sql.Query([[
        CREATE TABLE IF NOT EXISTS battalion_members (
            steamid TEXT,
            battalion TEXT,
            rank TEXT,
            joined_date INTEGER,
            PRIMARY KEY (steamid, battalion)
        )
    ]])
    
    -- Load existing data from database
    local data = sql.Query("SELECT * FROM battalion_members")
    if data then
        for _, row in ipairs(data) do
            if not BattalionSystem.Battalions[row.battalion] then
                BattalionSystem.Battalions[row.battalion] = {members = {}}
            end
            BattalionSystem.Battalions[row.battalion].members[row.steamid] = row.rank
        end
    end
end)

-- Add this at the top after the util.AddNetworkString section
local function InitializeBattalion(name)
    if not BattalionSystem.Battalions[name] then
        BattalionSystem.Battalions[name] = {
            members = {},
            created = os.time()
        }
    end
end

-- Initialize all battalions
hook.Add("Initialize", "BattalionSystem_Init", function()
    InitializeBattalion("Navy")
    InitializeBattalion("DT")
    InitializeBattalion("Marines")
    InitializeBattalion("Air Force")
    InitializeBattalion("Army")
    InitializeBattalion("Special Forces")
end)

concommand.Add("battalion_join", function(ply, cmd, args)
    local battalionName = args[1]
    
    if not battalionName then
        ply:ChatPrint("Usage: battalion_join <battalion name>")
        return
    end
    
    InitializeBattalion(battalionName)
    
    -- Set default rank
    local defaultRank = "Recruit"
    BattalionSystem.Battalions[battalionName].members[ply:SteamID()] = defaultRank
    
    -- Force save to database
    sql.Query("DELETE FROM battalion_members WHERE steamid = " .. sql.SQLStr(ply:SteamID()) .. " AND battalion = " .. sql.SQLStr(battalionName))
    
    local query = string.format([[
        INSERT INTO battalion_members (steamid, battalion, rank, joined_date)
        VALUES (%s, %s, %s, %d)
    ]], sql.SQLStr(ply:SteamID()), sql.SQLStr(battalionName), sql.SQLStr(defaultRank), os.time())
    
    sql.Query(query)
    print("[Battalion] Added player " .. ply:Nick() .. " to " .. battalionName)
    
    BattalionSystem.UpdateClients()
    ply:ChatPrint("You have joined " .. battalionName .. " as " .. defaultRank)
end)




-- Update the Initialize hook
hook.Add("Initialize", "BattalionSystem_DBInit", function()
    sql.Query([[
        CREATE TABLE IF NOT EXISTS battalion_members (
            steamid TEXT,
            battalion TEXT,
            rank TEXT,
            joined_date INTEGER,
            PRIMARY KEY (steamid, battalion)
        )
    ]])
    
    -- Load ALL existing data from database
    local data = sql.Query("SELECT * FROM battalion_members")
    BattalionSystem.Battalions = {} -- Reset the table first
    
    if data then
        for _, row in ipairs(data) do
            if not BattalionSystem.Battalions[row.battalion] then
                BattalionSystem.Battalions[row.battalion] = {members = {}}
            end
            BattalionSystem.Battalions[row.battalion].members[row.steamid] = row.rank
        end
    end
end)

-- Update PlayerInitialSpawn hook
hook.Add("PlayerInitialSpawn", "LoadBattalionData", function(ply)
    timer.Simple(2, function() -- Increased timer to ensure everything is loaded
        -- Force reload all data
        local data = sql.Query("SELECT * FROM battalion_members")
        BattalionSystem.Battalions = {}
        
        if data then
            for _, row in ipairs(data) do
                if not BattalionSystem.Battalions[row.battalion] then
                    BattalionSystem.Battalions[row.battalion] = {members = {}}
                end
                BattalionSystem.Battalions[row.battalion].members[row.steamid] = row.rank
            end
        end
        
        net.Start("BattalionSystem_Update")
        net.WriteTable(BattalionSystem.Battalions)
        net.Broadcast()
    end)
end)


concommand.Add("battalion_setrank", function(ply, cmd, args)
    if not ply:IsSuperAdmin() then return end
    
    -- The first argument is the target player's Steam ID, second is the battalion name, and third is the rank
    local targetSteamID = args[1]
    local battalionName = args[2]
    local rank = args[3]
    
    -- Validate arguments
    if not targetSteamID or not battalionName or not rank then
        ply:ChatPrint("Usage: battalion_setrank <steamid> <battalion name> <rank>")
        return
    end

    -- Check if the battalion exists
    if not BattalionSystem.Battalions[battalionName] then
        BattalionSystem.Battalions[battalionName] = {members = {}}
    end

    -- Check if the rank exists in the battalion's rank data
    if not battalionRanks[battalionName] or not battalionRanks[battalionName][rank] then
        ply:ChatPrint("Invalid rank for the specified battalion.")
        return
    end

    -- Ensure the player exists in the battalion, if not create an entry for them
    if not BattalionSystem.Battalions[battalionName].members[targetSteamID] then
        BattalionSystem.Battalions[battalionName].members[targetSteamID] = {}
    end

    -- Set the rank and level for the target player in the battalion system
    BattalionSystem.Battalions[battalionName].members[targetSteamID] = rank
    
    -- Get the rank level from the battalionRanks table
    local rankLevel = battalionRanks[battalionName][rank].level
    
    -- Set the player's rank and level using networked variables
    local targetPlayer = player.GetBySteamID(targetSteamID)
    if IsValid(targetPlayer) then
        targetPlayer:SetNWString("battalion_rank", rank)
        targetPlayer:SetNWInt("battalion_level", rankLevel)
    end

    -- Optionally store the rank and level in the database
    sql.Query(string.format([[
        INSERT OR REPLACE INTO battalion_members (steamid, battalion, rank, level, joined_date)
        VALUES (%s, %s, %s, %d, %d)
    ]], sql.SQLStr(targetSteamID), sql.SQLStr(battalionName), sql.SQLStr(rank), rankLevel, os.time()))

    -- Update all clients to reflect changes
    BattalionSystem.UpdateClients()

    -- Inform the superadmin about the change
    ply:ChatPrint("Successfully set " .. targetSteamID .. "'s rank to " .. rank .. " with level " .. rankLevel .. " in " .. battalionName)

    -- Inform the target player about their new rank
    local targetPlayer = player.GetBySteamID(targetSteamID)
    if IsValid(targetPlayer) then
        targetPlayer:ChatPrint("Your rank has been set to " .. rank .. " with level " .. rankLevel .. " in " .. battalionName)
    end
end)






net.Receive("Battalion_InvitePlayer", function(len, ply)
    local steamid = net.ReadString()
    local battalionName = net.ReadString()
    
    InitializeBattalion(battalionName)
    
    -- Set default rank
    local defaultRank = "Recruit"
    BattalionSystem.Battalions[battalionName].members[steamid] = defaultRank
    
    -- Force save to database
    sql.Query("DELETE FROM battalion_members WHERE steamid = " .. sql.SQLStr(steamid) .. " AND battalion = " .. sql.SQLStr(battalionName))
    
    local query = string.format([[
        INSERT INTO battalion_members (steamid, battalion, rank, joined_date)
        VALUES (%s, %s, %s, %d)
    ]], sql.SQLStr(steamid), sql.SQLStr(battalionName), sql.SQLStr(defaultRank), os.time())
    
    sql.Query(query)
    print("[Battalion] Player " .. steamid .. " invited to " .. battalionName)
    
    BattalionSystem.UpdateClients()
end)

net.Receive("Battalion_PromotePlayer", function(len, ply)
    local steamid = net.ReadString()
    local battalionName = net.ReadString()
    local newRank = net.ReadString()
    
    BattalionSystem.Battalions[battalionName].members[steamid] = newRank
    
    local query = string.format([[
        UPDATE battalion_members 
        SET rank = %s
        WHERE steamid = %s AND battalion = %s
    ]], sql.SQLStr(newRank), sql.SQLStr(steamid), sql.SQLStr(battalionName))
    
    sql.Query(query)
    print("[Battalion] Player " .. steamid .. " promoted to " .. newRank .. " in " .. battalionName)
    
    BattalionSystem.UpdateClients()
end)

net.Receive("Battalion_DemotePlayer", function(len, ply)
    local steamid = net.ReadString()
    local battalionName = net.ReadString()
    local newRank = net.ReadString()
    
    sql.Query(string.format([[
        UPDATE battalion_members 
        SET rank = '%s'
        WHERE steamid = '%s' AND battalion = '%s'
    ]], sql.SQLStr(newRank), sql.SQLStr(steamid), sql.SQLStr(battalionName)))
    
    BattalionSystem.Battalions[battalionName].members[steamid] = newRank
    
    net.Start("BattalionSystem_Update")
    net.WriteTable(BattalionSystem.Battalions)
    net.Broadcast()
end)

net.Receive("Battalion_KickPlayer", function(len, ply)
    local steamid = net.ReadString()
    local battalionName = net.ReadString()
   
    -- Remove from current session
    BattalionSystem.Battalions[battalionName].members[steamid] = nil
   
    -- Remove from database permanently
    sql.Query(string.format([[
        DELETE FROM battalion_members 
        WHERE steamid = %s AND battalion = %s
    ]], sql.SQLStr(steamid), sql.SQLStr(battalionName)))
   
    -- Add to kicked players table in database if it doesn't exist
    sql.Query([[
        CREATE TABLE IF NOT EXISTS battalion_kicked_players (
            steamid TEXT,
            battalion TEXT,
            kick_date INTEGER,
            PRIMARY KEY (steamid, battalion)
        )
    ]])
    
    -- Record the kick
    sql.Query(string.format([[
        INSERT INTO battalion_kicked_players (steamid, battalion, kick_date)
        VALUES (%s, %s, %d)
    ]], sql.SQLStr(steamid), sql.SQLStr(battalionName), os.time()))
   
    print("[Battalion] Player " .. steamid .. " permanently kicked from " .. battalionName)
   
    BattalionSystem.UpdateClients()
end)

net.Receive("Battalion_JoinRequest", function(len, ply)
    local steamid = ply:SteamID()
    local battalionName = net.ReadString()
    
    -- Check if player was kicked
    local kickCheck = sql.QueryRow(string.format([[
        SELECT * FROM battalion_kicked_players 
        WHERE steamid = %s AND battalion = %s
    ]], sql.SQLStr(steamid), sql.SQLStr(battalionName)))
    
    if kickCheck then
        ply:ChatPrint("You have been permanently banned from " .. battalionName)
        return
    end
    
    -- Continue with normal join process if not kicked
    if not BattalionSystem.Battalions[battalionName] then
        BattalionSystem.Battalions[battalionName] = {members = {}}
    end
    
    BattalionSystem.Battalions[battalionName].members[steamid] = "Recruit"
    
    sql.Query(string.format([[
        INSERT OR REPLACE INTO battalion_members (steamid, battalion, rank, joined_date)
        VALUES (%s, %s, 'Recruit', %d)
    ]], sql.SQLStr(steamid), sql.SQLStr(battalionName), os.time()))
    
    BattalionSystem.UpdateClients()
end)




local webhooks = {
    ["Navy"] = "https://discord.com/api/webhooks/1333903449355587747/-JQ8kSlE8yuq3TGuKgcTls66zK3-1WoBt5OhFrEz_MSpfyGiTYpZj7Lsemz9FsPWbuVm",
    ["DT"] = "https://discord.com/api/webhooks/1335655726953009192/IMEKvjBhuqAsR3W4m2dy3DLfJ5l1m7oEGRVWpiGAWOavc8VXUy9pkgbFlQIfkAYY-9go",
    ["ISB"] = "https://discord.com/api/webhooks/1335655732120387614/zlNThs1hkx5f-QsFK15rmKDKXIiGSMaedyCVusy_IuQscOf8S5PT8xirWxqSgXchKp48",
    ["StormTroopers"] = "https://discord.com/api/webhooks/1335655974509346866/GEJ0aLEmm_BbOFO8gokxvgpw__aZaIkC5fz6IC7vcIYAEE8wv6sjd_HADWZYbu_-ol9d",
    ["Shock"] = "https://discord.com/api/webhooks/1335655732414124166/YIQLqtN_S5uTz-7naNJGGzvnweja24kUJjq7ivDJQFV73ea2LKZDDyMtIayVtiAKdCUM",
    ["Medical"] = "https://discord.com/api/webhooks/1335655730107383920/6T__H6b75Rlh0v16fm_ASokTpxaX6IeBbrAHlLpoe3n2IknaBUuPjLTMBgq5q_pG3H1c",
    ["Imperial Commandos"] = "https://discord.com/api/webhooks/1335657130820243528/WfRvO7y-Mc-ftUtcaRFV8PE5WGB0r-wEQnJDAzB8SmRBEKKp2gXGbjPX4KtxJWS8_l4y",
    ["501st"] = "https://discord.com/api/webhooks/1335655728408559686/-BMeM-Yi_ClXMgPKbe2YB8Z0GINHJuRHj5qIBVDHB_-6zkFh03CUSCJvx-yRQXqh4PIK"
}

local function SendDiscordWebhook(battalion, message, color)
    if not webhooks[battalion] then return end
    
    HTTP({
        url = webhooks[battalion],
        method = "POST",
        headers = {
            ["Content-Type"] = "application/json"
        },
        body = util.TableToJSON({
            embeds = {
                {
                    title = battalion .. " Update",
                    description = message,
                    color = color or 3447003
                }
            }
        }),
        success = function(code, body, headers)
            print("Discord webhook sent for " .. battalion)
        end
    })
end

net.Receive("Battalion_InvitePlayer", function(len, ply)
    local steamid = net.ReadString()
    local battalionName = net.ReadString()
    
    sql.Query(string.format([[
        INSERT OR REPLACE INTO battalion_members (steamid, battalion, rank, joined_date)
        VALUES ('%s', '%s', 'Recruit', %d)
    ]], sql.SQLStr(steamid), sql.SQLStr(battalionName), os.time()))
    
    if not BattalionSystem.Battalions[battalionName] then
        BattalionSystem.Battalions[battalionName] = {members = {}}
    end
    BattalionSystem.Battalions[battalionName].members[steamid] = "Recruit"
    
    SendDiscordWebhook(battalionName, ply:Nick() .. " has joined " .. battalionName, 3066993)
    
    net.Start("BattalionSystem_Update")
    net.WriteTable(BattalionSystem.Battalions)
    net.Broadcast()
end)

net.Receive("Battalion_PromotePlayer", function(len, ply)
    local steamid = net.ReadString()
    local battalionName = net.ReadString()
    local newRank = net.ReadString()
    
    sql.Query(string.format([[
        UPDATE battalion_members 
        SET rank = '%s'
        WHERE steamid = '%s' AND battalion = '%s'
    ]], sql.SQLStr(newRank), sql.SQLStr(steamid), sql.SQLStr(battalionName)))
    
    BattalionSystem.Battalions[battalionName].members[steamid] = newRank
    
    SendDiscordWebhook(battalionName, steamid .. " has been promoted to " .. newRank, 15105570)
    
    net.Start("BattalionSystem_Update")
    net.WriteTable(BattalionSystem.Battalions)
    net.Broadcast()
end)

-- Add this near the top with other net messages

-- Add this to sv_battalion_core.lua


local WEBHOOKS = {
    ["Navy"] = "https://discord.com/api/webhooks/1333903449355587747/-JQ8kSlE8yuq3TGuKgcTls66zK3-1WoBt5OhFrEz_MSpfyGiTYpZj7Lsemz9FsPWbuVm",
    ["DT"] = "DT_WEBHOOK_URL",
    ["ISB"] = "https://discord.com/api/webhooks/1327707295777554503/vabNv8oA6VcJqaeQnqjCWOEkm6OIODc-gkleW6bHtO_wttC4Fg25ycLnYipCYVqWQ_w0",
    ["Chimaera Legion"] = "CHIMAERA_WEBHOOK_URL",
    ["StormTroopers"] = "STORMTROOPER_WEBHOOK_URL",
    ["Shock"] = "SHOCK_WEBHOOK_URL"
}

local ROLE_IDS = {
    ["Navy"] = "1283592870338629732",
    ["DT"] = "DT_ROLE_ID",
    ["ISB"] = "ISB_ROLE_ID",
    ["Chimaera Legion"] = "CHIMAERA_ROLE_ID",
    ["StormTroopers"] = "STORMTROOPER_ROLE_ID",
    ["Shock"] = "SHOCK_ROLE_ID"
}

net.Receive("Battalion_SendDiscordWebhook", function(len, ply)
    local playerName = net.ReadString()
    local battalionName = net.ReadString()
    local steamID = net.ReadString()
    local discordName = net.ReadString()
    local reason = net.ReadString()
    
    local webhookURL = WEBHOOKS[battalionName]
    local roleID = ROLE_IDS[battalionName]
    
    if webhookURL and roleID then
        HTTP({
            url = webhookURL,
            method = "POST",
            headers = {
                ["Content-Type"] = "application/json"
            },
            body = util.TableToJSON({
                content = string.format("<@&%s> New %s Application", roleID, battalionName),
                embeds = {
                    {
                        title = "Battalion Application",
                        fields = {
                            {name = "Player Name", value = playerName},
                            {name = "Discord Name", value = discordName},
                            {name = "Steam ID", value = steamID},
                            {name = "Reason for Joining", value = reason}
                        },
                        color = 5814783
                    }
                }
            }),
            success = function(code, body, headers)
                print("Discord webhook sent for " .. battalionName)
            end
        })
    end
end)



net.Receive("Battalion_DemotePlayer", function(len, ply)
    local steamid = net.ReadString()
    local battalionName = net.ReadString()
    local newRank = net.ReadString()
    
    sql.Query(string.format([[
        UPDATE battalion_members 
        SET rank = '%s'
        WHERE steamid = '%s' AND battalion = '%s'
    ]], sql.SQLStr(newRank), sql.SQLStr(steamid), sql.SQLStr(battalionName)))
    
    BattalionSystem.Battalions[battalionName].members[steamid] = newRank
    
    SendDiscordWebhook(battalionName, steamid .. " has been demoted to " .. newRank, 15158332)
    
    net.Start("BattalionSystem_Update")
    net.WriteTable(BattalionSystem.Battalions)
    net.Broadcast()
end)

net.Receive("Battalion_KickPlayer", function(len, ply)
    local steamid = net.ReadString()
    local battalionName = net.ReadString()
    
    sql.Query(string.format([[
        DELETE FROM battalion_members 
        WHERE steamid = '%s' AND battalion = '%s'
    ]], sql.SQLStr(steamid), sql.SQLStr(battalionName)))
    
    BattalionSystem.Battalions[battalionName].members[steamid] = nil
    
    SendDiscordWebhook(battalionName, steamid .. " has been kicked from " .. battalionName, 15158332)
    
    net.Start("BattalionSystem_Update")
    net.WriteTable(BattalionSystem.Battalions)
    net.Broadcast()
end)

function BattalionSystem.UpdateClients()
    net.Start("BattalionSystem_Update")
    net.WriteTable(BattalionSystem.Battalions)
    net.Broadcast()
end


function BattalionSystem.UpdateClients()
    net.Start("BattalionSystem_Update")
    net.WriteTable(BattalionSystem.Battalions)
    net.Broadcast()
end